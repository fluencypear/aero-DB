import copy
import json
from pathlib import Path
import sqlite3
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
import server


class AssetWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.original_db = server.DB
        server.DB = Path(self.temp.name) / 'knowledge.db'
        with server.connect() as connection:
            connection.executescript('CREATE TABLE assets(id INTEGER PRIMARY KEY, body TEXT); CREATE TABLE templates(id INTEGER PRIMARY KEY, body TEXT); CREATE TABLE history(id INTEGER PRIMARY KEY, created TEXT, body TEXT);')
            self.seed = json.loads((server.BASE / 'data' / 'seed.json').read_text())
            server.write_state(connection, self.seed)
        self.http = server.ThreadingHTTPServer(('127.0.0.1', 0), server.Handler)
        self.worker = threading.Thread(target=self.http.serve_forever)
        self.worker.start()

    def tearDown(self):
        self.http.shutdown()
        self.http.server_close()
        self.worker.join()
        server.DB = self.original_db
        self.temp.cleanup()

    def request(self, path, state=None, name='张三'):
        headers = {'Content-Type': 'application/json', 'X-Local-Token': server.TOKEN,
                   'X-Demo-User': name.encode().hex()}
        data = None if state is None else json.dumps(state).encode()
        url = 'http://127.0.0.1:' + str(self.http.server_port) + path
        with urllib.request.urlopen(urllib.request.Request(url, data=data, headers=headers)) as response:
            return json.load(response)

    def test_owner_tag_and_legacy_data(self):
        state = self.request('/api/state')
        self.assertTrue(all(r['owner'] == '待指定' and r['tag'] for r in state['assets']))
        new = copy.deepcopy(state['assets'][0])
        new.update(id=100, owner='伪造负责人', tag='', title='组织绩效', content='职责与绩效')
        state['assets'].append(new)
        self.request('/api/state', state)
        saved = self.request('/api/state')
        asset = next(r for r in saved['assets'] if r['id'] == 100)
        self.assertEqual((asset['owner'], asset['tag']), ('张三', '组织绩效'))
        self.assertEqual(saved['assets'][0]['owner'], '待指定')
        asset.update(owner='李四', tag='人工标签', tag_source='manual')
        self.request('/api/state', saved, '李四')
        actual = next(r for r in self.request('/api/state')['assets'] if r['id'] == 100)
        self.assertEqual((actual['owner'], actual['tag'], actual['tag_source']), ('张三', '人工标签', 'manual'))
        with sqlite3.connect(server.DB) as connection:
            self.assertEqual(connection.execute('SELECT count(*) FROM history').fetchone()[0], 2)

    def test_missing_identity_rejected_without_write(self):
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request('/api/state', self.seed, '')
        self.assertEqual(error.exception.code, 400)
        with server.connect() as connection:
            self.assertEqual(connection.execute('SELECT count(*) FROM history').fetchone()[0], 0)

    def test_suggestion_and_invalid_state(self):
        tag = self.request('/api/tag', {'title': '市场订单', 'content': '交付量', 'domain': '产业与市场'})
        self.assertEqual(tag, {'tag': '市场分析', 'tag_source': 'offline_rule'})
        state = self.request('/api/state')
        state['assets'][0]['tag_source'] = 'unknown'
        with self.assertRaises(urllib.error.HTTPError) as error:
            self.request('/api/state', state)
        self.assertEqual(error.exception.code, 400)


if __name__ == '__main__':
    unittest.main()
