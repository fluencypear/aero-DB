# 航策 · 战略研究知识库 离线 demo v1.1

运行要求：电脑已安装 Python 3.8 或以上及现代浏览器。无需 pip，无需外网。
Windows：先完整解压，再双击 start.bat；不要直接打开 HTML。
Mac/Linux：进入解压目录执行 sh start.sh，也可运行 python3 server.py。
启动后会自动打开浏览器；如未打开，手动访问 http://127.0.0.1:8000 。
端口被占用时：python server.py --port 8001，并访问对应端口。
关闭服务窗口即可停止程序。

本版包含：动态词云登录页；输入姓名的演示登录；新增及拆解入库自动记录负责人；离线规则建议标签、手工修改和检索；SQLite 保存、历史快照和 JSON 备份。
无默认用户名或密码；输入自己的姓名即可。姓名登录不验证企业账号。

目录：
server.py              服务程序
web/index.html         词云登录页和工作台
 data/seed.json        首次初始化的示例资料
start.bat              Windows 启动脚本
start.command/start.sh Mac/Linux 启动脚本
tests/test_assets.py   后端测试，可执行 python -m unittest discover -s tests -v
升级说明.txt            保留本地数据的升级步骤

首次启动自动创建 data/knowledge.db，内置6条示例资产、3个模板。
程序不联网，不加载在线字体、图片或脚本；标签和报告均为规则生成。
本包不包含 Python 安装程序，也不包含你原来的数据库。

这仍是单机离线 demo：可以在断网的公司电脑本地运行。服务仅监听127.0.0.1，未增加跨电脑内网网址访问、企业账号认证或多人并发编辑。
若有旧数据，请先阅读升级说明.txt；保留旧数据库，勿用空数据库替换。
